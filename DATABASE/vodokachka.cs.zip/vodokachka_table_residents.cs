using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
namespace Vodokachka
{
    #region Residents
    public class Residents
    {
        #region Member Variables
        protected unknown _id;
        protected string _fio;
        protected unknown _area;
        protected unknown _start_date;
        #endregion
        #region Constructors
        public Residents() { }
        public Residents(string fio, unknown area, unknown start_date)
        {
            this._fio=fio;
            this._area=area;
            this._start_date=start_date;
        }
        #endregion
        #region Public Properties
        public virtual unknown Id
        {
            get {return _id;}
            set {_id=value;}
        }
        public virtual string Fio
        {
            get {return _fio;}
            set {_fio=value;}
        }
        public virtual unknown Area
        {
            get {return _area;}
            set {_area=value;}
        }
        public virtual unknown Start_date
        {
            get {return _start_date;}
            set {_start_date=value;}
        }
        #endregion
    }
    #endregion
}