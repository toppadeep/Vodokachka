using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
namespace Vodokachka
{
    #region Personal_access_tokens
    public class Personal_access_tokens
    {
        #region Member Variables
        protected unknown _id;
        protected string _tokenable_type;
        protected unknown _tokenable_id;
        protected string _name;
        protected string _token;
        protected string _abilities;
        protected unknown _last_used_at;
        protected unknown _expires_at;
        protected unknown _created_at;
        protected unknown _updated_at;
        #endregion
        #region Constructors
        public Personal_access_tokens() { }
        public Personal_access_tokens(string tokenable_type, unknown tokenable_id, string name, string token, string abilities, unknown last_used_at, unknown expires_at, unknown created_at, unknown updated_at)
        {
            this._tokenable_type=tokenable_type;
            this._tokenable_id=tokenable_id;
            this._name=name;
            this._token=token;
            this._abilities=abilities;
            this._last_used_at=last_used_at;
            this._expires_at=expires_at;
            this._created_at=created_at;
            this._updated_at=updated_at;
        }
        #endregion
        #region Public Properties
        public virtual unknown Id
        {
            get {return _id;}
            set {_id=value;}
        }
        public virtual string Tokenable_type
        {
            get {return _tokenable_type;}
            set {_tokenable_type=value;}
        }
        public virtual unknown Tokenable_id
        {
            get {return _tokenable_id;}
            set {_tokenable_id=value;}
        }
        public virtual string Name
        {
            get {return _name;}
            set {_name=value;}
        }
        public virtual string Token
        {
            get {return _token;}
            set {_token=value;}
        }
        public virtual string Abilities
        {
            get {return _abilities;}
            set {_abilities=value;}
        }
        public virtual unknown Last_used_at
        {
            get {return _last_used_at;}
            set {_last_used_at=value;}
        }
        public virtual unknown Expires_at
        {
            get {return _expires_at;}
            set {_expires_at=value;}
        }
        public virtual unknown Created_at
        {
            get {return _created_at;}
            set {_created_at=value;}
        }
        public virtual unknown Updated_at
        {
            get {return _updated_at;}
            set {_updated_at=value;}
        }
        #endregion
    }
    #endregion
}