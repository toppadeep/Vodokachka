using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
namespace Vodokachka
{
    #region Periods
    public class Periods
    {
        #region Member Variables
        protected unknown _id;
        protected unknown _begin_date;
        protected unknown _end_date;
        #endregion
        #region Constructors
        public Periods() { }
        public Periods(unknown begin_date, unknown end_date)
        {
            this._begin_date=begin_date;
            this._end_date=end_date;
        }
        #endregion
        #region Public Properties
        public virtual unknown Id
        {
            get {return _id;}
            set {_id=value;}
        }
        public virtual unknown Begin_date
        {
            get {return _begin_date;}
            set {_begin_date=value;}
        }
        public virtual unknown End_date
        {
            get {return _end_date;}
            set {_end_date=value;}
        }
        #endregion
    }
    #endregion
}