using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
namespace Vodokachka
{
    #region Rates
    public class Rates
    {
        #region Member Variables
        protected unknown _id;
        protected unknown _period_id;
        protected unknown _amount_price;
        protected unknown _create_date;
        #endregion
        #region Constructors
        public Rates() { }
        public Rates(unknown period_id, unknown amount_price, unknown create_date)
        {
            this._period_id=period_id;
            this._amount_price=amount_price;
            this._create_date=create_date;
        }
        #endregion
        #region Public Properties
        public virtual unknown Id
        {
            get {return _id;}
            set {_id=value;}
        }
        public virtual unknown Period_id
        {
            get {return _period_id;}
            set {_period_id=value;}
        }
        public virtual unknown Amount_price
        {
            get {return _amount_price;}
            set {_amount_price=value;}
        }
        public virtual unknown Create_date
        {
            get {return _create_date;}
            set {_create_date=value;}
        }
        #endregion
    }
    #endregion
}