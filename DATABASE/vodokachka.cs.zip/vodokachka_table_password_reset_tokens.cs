using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
namespace Vodokachka
{
    #region Password_reset_tokens
    public class Password_reset_tokens
    {
        #region Member Variables
        protected string _email;
        protected string _token;
        protected unknown _created_at;
        #endregion
        #region Constructors
        public Password_reset_tokens() { }
        public Password_reset_tokens(string token, unknown created_at)
        {
            this._token=token;
            this._created_at=created_at;
        }
        #endregion
        #region Public Properties
        public virtual string Email
        {
            get {return _email;}
            set {_email=value;}
        }
        public virtual string Token
        {
            get {return _token;}
            set {_token=value;}
        }
        public virtual unknown Created_at
        {
            get {return _created_at;}
            set {_created_at=value;}
        }
        #endregion
    }
    #endregion
}