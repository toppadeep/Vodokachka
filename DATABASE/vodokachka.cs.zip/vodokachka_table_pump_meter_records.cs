using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
namespace Vodokachka
{
    #region Pump_meter_records
    public class Pump_meter_records
    {
        #region Member Variables
        protected unknown _id;
        protected unknown _period_id;
        protected unknown _amount_volume;
        #endregion
        #region Constructors
        public Pump_meter_records() { }
        public Pump_meter_records(unknown period_id, unknown amount_volume)
        {
            this._period_id=period_id;
            this._amount_volume=amount_volume;
        }
        #endregion
        #region Public Properties
        public virtual unknown Id
        {
            get {return _id;}
            set {_id=value;}
        }
        public virtual unknown Period_id
        {
            get {return _period_id;}
            set {_period_id=value;}
        }
        public virtual unknown Amount_volume
        {
            get {return _amount_volume;}
            set {_amount_volume=value;}
        }
        #endregion
    }
    #endregion
}