using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
namespace Vodokachka
{
    #region Bills
    public class Bills
    {
        #region Member Variables
        protected unknown _id;
        protected unknown _resident_id;
        protected unknown _period_id;
        protected unknown _amount_rub;
        #endregion
        #region Constructors
        public Bills() { }
        public Bills(unknown resident_id, unknown period_id, unknown amount_rub)
        {
            this._resident_id=resident_id;
            this._period_id=period_id;
            this._amount_rub=amount_rub;
        }
        #endregion
        #region Public Properties
        public virtual unknown Id
        {
            get {return _id;}
            set {_id=value;}
        }
        public virtual unknown Resident_id
        {
            get {return _resident_id;}
            set {_resident_id=value;}
        }
        public virtual unknown Period_id
        {
            get {return _period_id;}
            set {_period_id=value;}
        }
        public virtual unknown Amount_rub
        {
            get {return _amount_rub;}
            set {_amount_rub=value;}
        }
        #endregion
    }
    #endregion
}