using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
namespace Vodokachka
{
    #region Failed_jobs
    public class Failed_jobs
    {
        #region Member Variables
        protected unknown _id;
        protected string _uuid;
        protected string _connection;
        protected string _queue;
        protected string _payload;
        protected string _exception;
        protected unknown _failed_at;
        #endregion
        #region Constructors
        public Failed_jobs() { }
        public Failed_jobs(string uuid, string connection, string queue, string payload, string exception, unknown failed_at)
        {
            this._uuid=uuid;
            this._connection=connection;
            this._queue=queue;
            this._payload=payload;
            this._exception=exception;
            this._failed_at=failed_at;
        }
        #endregion
        #region Public Properties
        public virtual unknown Id
        {
            get {return _id;}
            set {_id=value;}
        }
        public virtual string Uuid
        {
            get {return _uuid;}
            set {_uuid=value;}
        }
        public virtual string Connection
        {
            get {return _connection;}
            set {_connection=value;}
        }
        public virtual string Queue
        {
            get {return _queue;}
            set {_queue=value;}
        }
        public virtual string Payload
        {
            get {return _payload;}
            set {_payload=value;}
        }
        public virtual string Exception
        {
            get {return _exception;}
            set {_exception=value;}
        }
        public virtual unknown Failed_at
        {
            get {return _failed_at;}
            set {_failed_at=value;}
        }
        #endregion
    }
    #endregion
}