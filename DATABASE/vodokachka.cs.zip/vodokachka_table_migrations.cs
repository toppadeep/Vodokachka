using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
namespace Vodokachka
{
    #region Migrations
    public class Migrations
    {
        #region Member Variables
        protected int _id;
        protected string _migration;
        protected int _batch;
        #endregion
        #region Constructors
        public Migrations() { }
        public Migrations(string migration, int batch)
        {
            this._migration=migration;
            this._batch=batch;
        }
        #endregion
        #region Public Properties
        public virtual int Id
        {
            get {return _id;}
            set {_id=value;}
        }
        public virtual string Migration
        {
            get {return _migration;}
            set {_migration=value;}
        }
        public virtual int Batch
        {
            get {return _batch;}
            set {_batch=value;}
        }
        #endregion
    }
    #endregion
}