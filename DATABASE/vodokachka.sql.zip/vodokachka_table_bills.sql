
-- --------------------------------------------------------

--
-- Структура таблицы `bills`
--

DROP TABLE IF EXISTS `bills`;
CREATE TABLE `bills` (
  `id` bigint UNSIGNED NOT NULL,
  `resident_id` bigint UNSIGNED NOT NULL,
  `period_id` bigint UNSIGNED NOT NULL,
  `amount_rub` double(8,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `bills`
--

INSERT INTO `bills` (`id`, `resident_id`, `period_id`, `amount_rub`) VALUES
(1, 1, 1, 2176.00),
(2, 2, 2, 3127.29);
