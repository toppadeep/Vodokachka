
-- --------------------------------------------------------

--
-- Структура таблицы `residents`
--

DROP TABLE IF EXISTS `residents`;
CREATE TABLE `residents` (
  `id` bigint UNSIGNED NOT NULL,
  `fio` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `area` double(8,2) NOT NULL,
  `start_date` timestamp NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `residents`
--

INSERT INTO `residents` (`id`, `fio`, `area`, `start_date`) VALUES
(1, 'Павлов Павел Павлович', 20.00, '2024-01-01 16:49:00'),
(2, 'Сергеев Сергей Сергеевич', 32.00, '2024-02-02 04:50:00'),
(3, 'Максимов Максим Максимович', 43.00, '2024-01-03 16:51:00'),
(4, 'Михайлов Михаил Михайлович', 100.00, '2024-01-04 16:51:00'),
(5, 'Юрьев Юрий Юрьевич', 12.00, '2024-01-05 16:52:00');
