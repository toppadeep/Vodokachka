
-- --------------------------------------------------------

--
-- Структура таблицы `periods`
--

DROP TABLE IF EXISTS `periods`;
CREATE TABLE `periods` (
  `id` bigint UNSIGNED NOT NULL,
  `begin_date` timestamp NOT NULL,
  `end_date` timestamp NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `periods`
--

INSERT INTO `periods` (`id`, `begin_date`, `end_date`) VALUES
(1, '2023-12-31 21:00:00', '2024-01-31 20:59:00'),
(2, '2024-01-31 21:00:00', '2024-02-29 20:59:00'),
(3, '2024-02-29 21:00:00', '2024-03-31 20:59:00'),
(4, '2024-03-31 21:00:00', '2024-04-30 20:59:00');
