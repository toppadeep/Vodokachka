
-- --------------------------------------------------------

--
-- Структура таблицы `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `personal_access_tokens`
--

INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `expires_at`, `created_at`, `updated_at`) VALUES
(1, 'App\\Models\\User', 2, 'token', 'b9eaa6cea927c6d2009d2da05c884ea542ad4139baba9132ee5b0749cce17a6b', '[\"*\"]', NULL, NULL, '2024-01-18 09:48:36', '2024-01-18 09:48:36'),
(2, 'App\\Models\\User', 4, 'token', '306c4fa8bc6b8a13b65a56b035e8dfb4afe383a6f6ea9b1dd1566f2020093b78', '[\"*\"]', NULL, NULL, '2024-01-19 03:30:03', '2024-01-19 03:30:03'),
(3, 'App\\Models\\User', 4, 'token', '4fddf745843773670f7d0692e66f04b0495e0fbf38505dd2885bb00cf12f425a', '[\"*\"]', NULL, NULL, '2024-01-19 03:30:39', '2024-01-19 03:30:39');
