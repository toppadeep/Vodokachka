
-- --------------------------------------------------------

--
-- Структура таблицы `rates`
--

DROP TABLE IF EXISTS `rates`;
CREATE TABLE `rates` (
  `id` bigint UNSIGNED NOT NULL,
  `period_id` bigint UNSIGNED NOT NULL,
  `amount_price` double(8,2) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `rates`
--

INSERT INTO `rates` (`id`, `period_id`, `amount_price`, `create_date`) VALUES
(1, 1, 145.00, '2024-01-18 13:00:04'),
(2, 2, 134.00, '2024-01-18 17:01:50'),
(3, 3, 134.34, '2024-01-19 06:20:22');
