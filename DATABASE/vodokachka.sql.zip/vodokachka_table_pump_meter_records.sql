
-- --------------------------------------------------------

--
-- Структура таблицы `pump_meter_records`
--

DROP TABLE IF EXISTS `pump_meter_records`;
CREATE TABLE `pump_meter_records` (
  `id` bigint UNSIGNED NOT NULL,
  `period_id` bigint UNSIGNED NOT NULL,
  `amount_volume` double(8,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `pump_meter_records`
--

INSERT INTO `pump_meter_records` (`id`, `period_id`, `amount_volume`) VALUES
(1, 1, 145.00),
(2, 2, 140.00),
(3, 3, 130.00);
